public class Main {
	public static void main(String[] args) {
		PollingDevice pd = new PollingDevice();
		pd.screen();
		
	}
}